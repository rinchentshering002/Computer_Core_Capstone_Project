﻿# build.ps1 — build, trim, and serve THE CORE
Write-Host "=== Building ===" -ForegroundColor Cyan
pygbag --build main.py

Write-Host "=== Trimming web build ===" -ForegroundColor Cyan
Remove-Item build\web\computercore.apk -ErrorAction SilentlyContinue

if (Test-Path build\web\assets) {
    Get-ChildItem build\web\assets -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne "voice" } |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path build\web\assets -Force | Out-Null
Remove-Item -Recurse -Force build\web\assets\voice -ErrorAction SilentlyContinue
Copy-Item -Recurse assets\voice build\web\assets\voice -Force

$count = (Get-ChildItem build\web\assets\voice -Recurse -File).Count
Write-Host "Voice files in build/web: $count" -ForegroundColor Green

Write-Host "=== Serving at http://localhost:8000 ===" -ForegroundColor Cyan
pygbag main.py